package co.admission.service;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.admission.exception.AdmissionException;

public class AdmissionValidator {

	static boolean validateData(String name,String pattern){
		if(name.matches(pattern)){
			return true;
		}
		else
		{
			return false;
		}
	}

	public static boolean validateName(String name) {
		String pattern="[A-Za-z]{3,}";
		if(validateData(name,pattern))
			return true;
		else{
			return false;
		}
	}

	public static boolean validateMobileNo(String mobile) {
		String pattern="[7|8|9][0-9]{9}";
		if(validateData(mobile,pattern))
			return true;
		else{
			return false;
		}
	}

	public static boolean validateEmail(String email) {
		String pattern = 	"^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		if(validateData(email,pattern))
			return true;
		else{
			return false;//throws new AdmissionException();
		}
	}

	public static boolean validateStream(String stream) {
		if(stream.equals("Computer Science")||stream.equals("Information Technology"))
		{
			return true;
		}
		else
			return false;
	}

	public static boolean validateAggMarks(String aggMarks) {
		String pattern="[0-9]{1,}";
		if(validateData(aggMarks,pattern)){
			return true;
		}
		else{
			return false;
		}
	}
}
