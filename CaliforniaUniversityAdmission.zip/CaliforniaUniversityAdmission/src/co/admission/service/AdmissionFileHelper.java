package co.admission.service;
import java.util.ArrayList;
import java.util.Iterator;
import com.admission.bean.AdmissionDetails;
public class AdmissionFileHelper{
	public static ArrayList<AdmissionDetails> arrayList=null;
	static{
		arrayList=new ArrayList<AdmissionDetails>();
	}
	public void writeAdmissionDetails(AdmissionDetails ad){
		arrayList.add(ad);
	}
	public void readAdmissionDetails(){
		Iterator<AdmissionDetails> itr= arrayList.iterator();
		while(itr.hasNext()){
			AdmissionDetails ad= itr.next();
			System.out.println(ad);
		}
	}
	public boolean deleteAdmissionDetails(String mobile) {
		boolean deleted=false;
		Iterator<AdmissionDetails> itr= arrayList.iterator();
		while(itr.hasNext()){
			AdmissionDetails ad = itr.next();
			if(ad.getMobileNo().equals(mobile)){
				arrayList.remove(ad);
				deleted=true;
				return deleted;
			}
			else
			{
				deleted=false;
			}
		}
		return deleted;
	}
}
