package com.admission.ui;

import java.util.Scanner;

import com.admission.bean.AdmissionDetails;

import co.admission.service.AdmissionFileHelper;
import co.admission.service.AdmissionValidator;

public class AdmissionClient {
	public static Scanner sc=new Scanner(System.in);

	static String fname,lname,mobile,email,stream,aggMarks,refId;
	public static AdmissionFileHelper admissioFileHelper = null;
	static{admissioFileHelper =new AdmissionFileHelper();}

	public static void main(String [] args){
		String choice="";
		sc=new Scanner(System.in);
		while(true){
			System.out.println("Enter your choice:\n1. Enter admission details\n2. Display admission details\n3. Delete admission details based on mobile no.\n4. Find No. of admission done.\n5. Exit");
			choice = sc.nextLine();
			switch(choice){
			case "1":
				registerNewApplicant();
				break;
			case "2":
				admissioFileHelper.readAdmissionDetails();
				break;
			case "3":
				if(AdmissionFileHelper.arrayList.size()>0)
				{
					if(inputMobile())
						if(admissioFileHelper.deleteAdmissionDetails(mobile))
						{
							System.out.println("Record deleted successfully.");
						}
						else{
							System.out.println("Mobile is not registered with California University.\n");
						}
				}
				else
					System.out.println("No record found in database");
				break;
			default:
				System.out.println("Invalid Input");

			}
		}

	}
	public static void registerNewApplicant() {
		if( inputFName() && inputLName() && inputMobile() && inputEmail()&&inputStream()&& inputAggMarks()){
			admissioFileHelper.writeAdmissionDetails(new AdmissionDetails(fname, lname, mobile, email, stream, aggMarks));
			System.out.println("Record Inserted");
			admissioFileHelper.readAdmissionDetails();

		}

	}
	public static boolean inputFName(){

		System.out.println("Enter first name");
		fname=sc.nextLine();
		if(AdmissionValidator.validateName(fname)){
			//	System.out.println("Valid First Name");
			return true;}
		else{
			System.out.println("Invalid First Name\nFirst Name must contain only characters and must be atleast 3 character long.\n");
			return inputFName();	
		}

	}
	public static boolean inputLName(){

		System.out.println("Enter last name");
		lname=sc.nextLine();
		if(AdmissionValidator.validateName(lname)){
			//System.out.println("Valid Last Name");
			return true;
		}
		else{
			System.out.println("Invalid last name\nLast Name must contain only characters and must be atleast 3 character long.\n");
			return inputLName();			
		}		
	}
	public static boolean inputMobile(){

		System.out.println("Enter mobile no.:");
		mobile=sc.nextLine();
		if(AdmissionValidator.validateMobileNo(mobile)){
			return true;
		}
		else{
			System.out.println("Invalid Mobile No");
			return inputMobile();			
		}
	}
	public static boolean inputEmail(){

		System.out.println("Enter email:");
		email=sc.nextLine();
		if(AdmissionValidator.validateEmail(email)){
			return true;
		}
		else{
			System.out.println("Invalid Email");
			return inputEmail();			
		}
	}
	public static boolean inputStream(){

		System.out.println("Enter stream:");
		stream=sc.nextLine();
		if(AdmissionValidator.validateStream(stream)){
			return true;
		}
		else{
			System.out.println("Invalid Stream\n Stream must be either \nCoumputer Science or \nInformation Technology\n");
			return inputStream();			
		}
	}
	public static boolean inputAggMarks(){
		System.out.println("Enter Aggregate Marks:");
		aggMarks=sc.nextLine();
		if(AdmissionValidator.validateAggMarks(aggMarks)){
			return true;
		}
		else{
			System.out.println("Invalid Aggregate Marks");
			return inputAggMarks();			
		}

	}



}
