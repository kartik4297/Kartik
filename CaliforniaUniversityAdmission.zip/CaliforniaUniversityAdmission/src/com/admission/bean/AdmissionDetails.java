package com.admission.bean;

public class AdmissionDetails {
private String firstName;
private String lastName;
private String mobileNo;
private String email;
private String stream;
public AdmissionDetails(String firstName, String lastName, String mobileNo,
		String email, String stream, String aggMarks) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.mobileNo = mobileNo;
	this.email = email;
	this.stream = stream;
	this.aggMarks = aggMarks;
}
public AdmissionDetails() {
	// TODO Auto-generated constructor stub
}
private String aggMarks;
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getemail() {
	return email;
}
public void setemail(String email) {
	this.email = email;
}
public String getStream() {
	return stream;
}
public void setStream(String stream) {
	this.stream = stream;
}
public String getAggMarks() {
	return aggMarks;
}
public void setAggMarks(String aggMarks) {
	this.aggMarks = aggMarks;
}
@Override
public String toString() {
	String str="\nFirst Name:  "+firstName+"\nLast Name:  "+lastName+"\nMobile No.: "+mobileNo+
"\nEmail: "+email+"\nStream: "+stream+"\nAggregate Marks: "+aggMarks+"\n---------------------";
	return str;
}



}
